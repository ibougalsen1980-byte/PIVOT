// PIVOT, confirmation serveur d'un paiement Stripe et écriture de l'accès dans Supabase.
//
// Pourquoi cette fonction existe : avant elle, l'application faisait confiance à une valeur
// stockée dans le navigateur (DB.sub.until) pour savoir si le coach avait un accès payant actif.
// N'importe qui pouvait modifier cette valeur depuis la console du navigateur et obtenir un accès
// illimité, y compris répliqué sur ses autres appareils via la synchronisation cloud. Cette fonction
// vérifie le paiement directement auprès de Stripe, puis écrit l'accès dans une colonne Supabase que
// le navigateur ne peut jamais modifier lui-même (clé de service, jamais envoyée au client).
//
// Variables d'environnement Netlify nécessaires :
//   STRIPE_SECRET_KEY       clé secrète Stripe (Dashboard Stripe, Développeurs, Clés API)
//   SUPABASE_URL            déjà configurée (utilisée par coach.js pour la limite anti-abus)
//   SUPABASE_SERVICE_ROLE   déjà configurée (idem)
//
// Correspondance prix -> durée, à mettre à jour si les prix de STRIPE_LINKS changent dans index.html.
const PRICE_TO_DAYS = {
  299: { days: 7, plan: 'semaine' },
  899: { days: 30, plan: 'mois' },
  7999: { days: 365, plan: 'annee' }
};

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS'
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  if (event.httpMethod !== 'GET') return { statusCode: 405, headers, body: JSON.stringify({ ok: false, error: 'method' }) };

  const sessionId = event.queryStringParameters && event.queryStringParameters.session_id;
  if (!sessionId) return { statusCode: 400, headers, body: JSON.stringify({ ok: false, error: 'session_id manquant' }) };

  if (!process.env.STRIPE_SECRET_KEY) {
    return { statusCode: 500, headers, body: JSON.stringify({ ok: false, error: 'Stripe non configuré côté serveur' }) };
  }
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE) {
    return { statusCode: 500, headers, body: JSON.stringify({ ok: false, error: 'Supabase non configuré côté serveur' }) };
  }

  try {
    const sr = await fetch('https://api.stripe.com/v1/checkout/sessions/' + encodeURIComponent(sessionId), {
      headers: { 'Authorization': 'Bearer ' + process.env.STRIPE_SECRET_KEY }
    });
    const session = await sr.json();
    if (!sr.ok || !session) {
      return { statusCode: 200, headers, body: JSON.stringify({ ok: false, error: 'session Stripe introuvable' }) };
    }
    if (session.payment_status !== 'paid') {
      return { statusCode: 200, headers, body: JSON.stringify({ ok: false, error: 'paiement non confirmé' }) };
    }
    const userId = session.client_reference_id;
    if (!userId) {
      // Ne devrait pas arriver en usage normal : PIVOT exige un compte connecté avant d'envoyer vers Stripe.
      return { statusCode: 200, headers, body: JSON.stringify({ ok: false, error: 'compte non identifié, contacte le support' }) };
    }
    const mapping = PRICE_TO_DAYS[session.amount_total];
    if (!mapping) {
      return { statusCode: 200, headers, body: JSON.stringify({ ok: false, error: 'montant non reconnu' }) };
    }

    const grant = await grantServerAccess(userId, mapping.days, mapping.plan);
    if (!grant.ok) {
      return { statusCode: 200, headers, body: JSON.stringify({ ok: false, error: 'écriture Supabase impossible' }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify({ ok: true, days: mapping.days, plan: mapping.plan }) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ ok: false, error: 'serveur' }) };
  }
};

// Étend (ou crée) l'accès d'un utilisateur dans coach_data, en repartant de sub_until s'il est encore
// dans le futur, sinon de maintenant. Utilise la clé de service, qui ignore toute politique de sécurité
// niveau ligne : seule cette fonction (jamais le navigateur) peut écrire ces colonnes.
async function grantServerAccess(userId, days, plan) {
  const base = process.env.SUPABASE_URL;
  const svcHeaders = {
    'apikey': process.env.SUPABASE_SERVICE_ROLE,
    'authorization': 'Bearer ' + process.env.SUPABASE_SERVICE_ROLE,
    'content-type': 'application/json'
  };
  try {
    const cur = await fetch(base + '/rest/v1/coach_data?user_id=eq.' + encodeURIComponent(userId) + '&select=sub_until', { headers: svcHeaders });
    const rows = cur.ok ? await cur.json() : [];
    const currentUntil = (rows && rows[0] && rows[0].sub_until) ? new Date(rows[0].sub_until).getTime() : 0;
    const newUntil = (currentUntil > Date.now() ? currentUntil : Date.now()) + days * 86400000;
    const w = await fetch(base + '/rest/v1/coach_data', {
      method: 'POST',
      headers: Object.assign({}, svcHeaders, { 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
      body: JSON.stringify([{ user_id: userId, sub_until: new Date(newUntil).toISOString(), sub_plan: plan }])
    });
    return { ok: w.ok };
  } catch (e) {
    return { ok: false };
  }
}
