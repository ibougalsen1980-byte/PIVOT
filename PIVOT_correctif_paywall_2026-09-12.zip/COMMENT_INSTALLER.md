# Corriger le paywall PIVOT, sur GitHub sans ligne de commande

Ce lot corrige la faille critique de l'audit : l'accès payant reposait entièrement sur une donnée modifiable dans le navigateur. Il faut uploader des fichiers ET ajouter deux réglages dans Netlify. Sans ces réglages, le paiement Stripe et les codes d'accès ne fonctionneront plus du tout, donc les deux étapes sont obligatoires, pas optionnelles.

## Ce qui a changé, en clair

Avant, `hasAccess()` regardait une valeur stockée dans le navigateur (`DB.sub.until`). N'importe qui pouvait l'ouvrir dans la console du navigateur et se donner un accès de plusieurs années, gratuitement, et cette valeur se propageait ensuite sur tous ses appareils via la synchronisation. En creusant plus loin, j'ai aussi trouvé que les codes d'accès maîtres ("PIVOT-OWNER-2026" et "PIVOT-TESTEUR-2026") étaient écrits en clair dans le fichier de l'application : n'importe quel visiteur pouvait les lire en faisant un simple clic droit, "Afficher le code source", sans même toucher à la console. C'était plus grave que le premier point, parce que ça ne demandait aucune compétence technique.

Maintenant :
- L'accès payant est vérifié et écrit uniquement par le serveur (une nouvelle fonction Netlify qui interroge Stripe directement), jamais par une valeur envoyée par le navigateur.
- Les codes d'accès ne sont plus dans le fichier de l'application. Ils vivent uniquement dans un réglage Netlify que toi seul peux voir et modifier.
- L'application revérifie l'accès auprès du serveur toutes les 5 minutes et à chaque fois que tu reviens sur l'onglet, pour réduire encore la fenêtre où une valeur bricolée localement pourrait avoir un effet, le temps qu'elle tourne dans le navigateur avant ce contrôle.

## Ce que contient ce dossier

- `index.html` : la correction du paywall côté application (plus les correctifs précédents, chrono et exercices, déjà inclus).
- `netlify.toml` : ajoute les adresses `/api/verify` et `/api/redeem-code` utilisées par l'application.
- `netlify/functions/verify.js` : nouvelle fonction serveur, confirme un paiement directement auprès de Stripe et écrit l'accès dans Supabase.
- `netlify/functions/redeem-code.js` : nouvelle fonction serveur, vérifie un code d'accès à partir du réglage Netlify, jamais du fichier de l'application.

## Étape 1, les fichiers, sur github.com

1. Va sur `github.com/ibougalsen1980-byte/PIVOT`.
2. Pour `index.html` et `netlify.toml` : clique sur le fichier, icône crayon (Edit this file), sélectionne tout, supprime, colle le contenu fourni ici, puis **Commit changes** en bas de page.
3. Pour les deux nouveaux fichiers : clique sur **Add file** puis **Create new file**. Dans le champ du nom, tape `netlify/functions/verify.js` (le `/` crée le dossier automatiquement puisqu'il existe déjà), colle le contenu, **Commit changes**. Fais la même chose pour `netlify/functions/redeem-code.js`.
4. Va sur ton tableau de bord Netlify, attends le badge vert "Published" du déploiement automatique.

## Étape 2, les réglages Netlify, indispensable

Sur ton tableau de bord Netlify : Site settings, puis Environment variables. Deux nouvelles variables à ajouter, en plus de celles déjà en place (`ANTHROPIC_API_KEY`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE`) :

- `STRIPE_SECRET_KEY` : ta clé secrète Stripe. Elle se trouve sur dashboard.stripe.com, Développeurs, Clés API, "Clé secrète" (commence par `sk_live_`). Ne la partage jamais ailleurs que dans ce réglage Netlify.
- `PIVOT_ACCESS_CODES` : les codes d'accès manuels, au format suivant, en une seule ligne :
  `{"PIVOT-OWNER-2026":3650,"PIVOT-TESTEUR-2026":21}`
  Tu peux changer les codes eux-mêmes ou en ajouter, du moment que le format reste `"CODE":nombre de jours`. Si tu changes un code ici, il faudra le redonner à qui doit l'utiliser, puisqu'il n'apparaît plus nulle part dans l'application.

Après avoir ajouté ces deux variables, redéploie le site une fois depuis Netlify (Trigger deploy, "Clear cache and deploy site") pour qu'elles soient prises en compte par les fonctions.

## Vérifier que ça a marché

- Paiement : passe par un vrai pass Stripe (le moins cher, semaine) sur un compte de test si tu en as un, ou vérifie que le message "Abonnement activé, bienvenue" s'affiche bien après un paiement réel et que l'accès reste actif au rechargement.
- Code d'accès : connecte-toi avec un compte, utilise "J'ai un code" avec `PIVOT-TESTEUR-2026`, l'accès doit s'activer avec le message "Accès activé".
- Dans la console du navigateur (F12), essaie `DB.sub.until=Date.now()+999*86400000; save()` sur un compte sans accès payant : l'accès élargi doit disparaître après un rechargement de la page, ou au plus tard 5 minutes après si tu laisses l'onglet ouvert.

## Ce qui reste à vérifier, en dehors de ce que je peux faire depuis ici

Je n'ai pas accès à ton tableau de bord Supabase, donc un point ne peut être vérifié que par toi : dans Supabase, Authentication puis Policies (RLS) sur la table `coach_data`, assure-toi que la politique qui autorise un utilisateur connecté à modifier sa propre ligne ne permette pas la modification des colonnes `sub_until` et `sub_plan`. Si une politique générale du type "l'utilisateur peut modifier sa ligne" existe sans restriction de colonnes, quelqu'un de suffisamment averti pourrait encore appeler l'API Supabase directement (pas via l'application) pour écrire ces colonnes lui-même. Le plus sûr, si Supabase le permet sur ton plan, est une politique séparée qui exclut ces deux colonnes de ce que l'utilisateur peut modifier lui-même, seule la clé de service (utilisée par les nouvelles fonctions serveur) devant pouvoir les écrire.
